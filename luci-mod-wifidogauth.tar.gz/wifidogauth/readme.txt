modules目录下的wifidogauth目录放到./feeds/luci/modules/下。
po/zh_CN/wifidogauth.po文件放到./feeds/luci/po/zh_CN/下。

./feeds/luci/contrib/package/luci/Makefile增加如下语句：
$(eval $(call module,wifidogauth,wifidog auth server,+luci-base))

然后 make menuconfig在luci-->Modules下找到luci-mod-wifidogauth选上。

make package/feeds/luci/luci/compile V=s
