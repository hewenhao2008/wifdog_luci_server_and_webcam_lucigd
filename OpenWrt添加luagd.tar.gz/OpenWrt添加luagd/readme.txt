把本目录下的luagd目录放到openwrt源码的feeds/packages/lang/目录下。
在openwrt源码目录下执行：
./scripts/feeds update -i
./scripts/feeds install luagd
make menuconfig 在Languages-->lang-->Lua找到LuaGD选上。
make package/luagd/compile V=s

路由上安装luagd（注：luagd依赖libgd，因此需先安装libgd）
checkcode是测试文件，放到openwrt的/www/cgi-bin/下，并赋予checkcode可执行的权限，
即chmod 755 checkcode

浏览器访问http://路由ip/cgi-bin/checkcode即可看到效果。
