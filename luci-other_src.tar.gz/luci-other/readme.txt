./feeds/luci/contrib/package/luci/Makefile增加如下语句：
$(eval $(call application,other,luci my other application))

然后 ./scripts/feeds update -i
./scripts/feeds install luci-app-other

make package/feeds/luci/luci/compile V=s
